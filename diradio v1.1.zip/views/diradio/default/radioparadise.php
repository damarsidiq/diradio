<?php 

echo $pagevar['url'];

?>