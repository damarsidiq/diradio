<script type="text/javascript">
var mobile = <?php if(isset($pagevar['mobile'])) echo $pagevar['mobile']; else echo 'false'; ?>;
</script>
</body>
<?php $velp->printfootsrc(); ?>
</html>