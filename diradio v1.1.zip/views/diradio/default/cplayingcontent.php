<div id="songtitle">
    <div class="table">
        <div class="tablecell">
            <?php
            
            echo $pagevar['cplaying'];
            
            ?>
        </div>
    </div>    
</div>