<?php 

if(isset($pagevar['windowopen'])){

?>


<div style="display:table;height:75%;width:100%;">
    <div id="preq" style="display:table-cell;height:100%;width:100%;vertical-align:middle;text-align:center;font-size:17px">
        processing request
    </div>
</div>

<script type="text/javascript">
var recordingpage = true;
var recordingwindow = true;
</script>

<?php }else{ 


if(isset($pagevar['open'])){

?>

<div style="display:table;height:100%;width:100%;">
    <div style="display:table-cell;height:100%;width:100%;vertical-align:middle;text-align:center;font-size:23px">
        <?php foreach($pagevar['recordingurl'] as $i=>$xv){ ?>
            <audio style="position:relative;width:100%;height:auto;" autoplay="false" controls="controls" src="<?php echo $xv; ?>"></audio>
        <?php } ?>
    </div>
</div>

<?php }else{ ?>


<div style="display:table;height:100%;width:100%;">
    <div style="display:table-cell;height:100%;width:100%;vertical-align:middle;text-align:center;font-size:18px">
        recording stopped
    </div>
</div>

<?php } ?>


<script type="text/javascript">
var recordingpage = true;
</script>


<?php } ?>