const electron = require('electron')
const app = electron.app
const BrowserWindow = electron.BrowserWindow

let win,win2,count


win = false;
win2 = false;

const {ipcMain} = require('electron')
ipcMain.on('asynchronous-message', (event, arg) => {
  if(arg.split('<edsep>')[0] == 'quitbro'){
      if(win)
        win.destroy();
      if(win2!=false)
        win2.destroy();
  }
  else if(arg.split('<edsep>')[0] == 'stoprecord'){
    win2.destroy();
  }
  else{
      draw();
      win.webContents.session.clearCache(function(){});
      win.destroy();
  }
})

count = 0;
function draw() {
    count+=1;
    switch(count){
        case 1:
            win = new BrowserWindow({ icon:'/media/damarsidiq/pic/icons/diradio.png',width: 360, height: 600, frame:false,resizable: true,x:980,y:145});
            win.webContents.session.clearCache(function(){});
            win.setTitle('DiradiO');
            //win.setMenu(null);
            //win.webContents.openDevTools();
            win.isMaximizable(true);
            win.isResizable(true);
            win.setAlwaysOnTop(false, "floating");
            win.loadURL('http://pxpedia/pxpedia/?app=diradio&d[electronapp]=1');
            win.show();
        break;
        case 2:
            win2 = new BrowserWindow({ icon:'/media/damarsidiq/pic/icons/diradio.png',width: 300, height: 600, frame:false,resizable: true,x:980,y:145});
            win2.webContents.session.clearCache(function(){});
            win2.setTitle('DiradiO');
            //win.setMenu(null);
            //win.webContents.openDevTools();
            win2.isMaximizable(true);
            win2.isResizable(true);
            win2.setAlwaysOnTop(false, "floating");
            win2.loadURL('http://pxpedia/pxpedia/?app=diradio&p=radioparadise&a=startrecordingwindow&d[electronapp]=1');
            win2.show();
        break;
    }
}
app.on('ready', draw)
