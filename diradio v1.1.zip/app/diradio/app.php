<?php
if(!class_exists('Pxpedia')){
	die();
}
Class App extends Pxpedia{
    /*website*/
    function __construct(){
		parent::__construct();
		
    }
    
    public static function getMp3StreamTitle($name,$streamingUrl, $interval, $offset = 0, $headers = true,$limit=0)
    {
		if($limit == 3){
			return false;
		}
		$needle = 'StreamTitle=';
		$ua = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36';
		$opts = [
			'http' => [
				'method' => 'GET',
				'header' => 'Icy-MetaData: 1',
				'user_agent' => $ua
			]
		];
		
		
		$headervalue            = array();
		$headervalue['int']     = $interval;
		$headervalue['name']    = $name;
		if(App::getSessionVar('streamingurl') != false && explode('<^edelemsep^>',App::getSessionVar('streamingurl'))[0] == $streamingUrl){
		    $headerx = explode('<^edelemsep^>',App::getSessionVar('streamingurl'));
	        $headervalue['int']     = $headerx[1];
	        $headervalue['name']    = $headerx[2];
		}
		else{
		    if (($headers = get_headers($streamingUrl))){
		     	foreach ($headers as $h){
    		        if (strpos(strtolower($h), 'icy-metaint') !== false && ($interval = explode(':', $h)[1])){
    				    $headervalue['int'] = $interval;
    				}
    				if (strpos(strtolower($h), 'icy-name') !== false){
    				    $headervalue['name'] = explode(':',$h);
    				    unset($headervalue['name'][0]);
    				    $headervalue['name'] = implode(':',$headervalue['name']);
    				}
    			}
    			App::setSessionVar('streamingurl',$streamingUrl.'<^edelemsep^>'.$headervalue['int'].'<^edelemsep^>'.$headervalue['name']);   
		    }
		}
					
		$context = stream_context_create($opts);
		if ($stream = @fopen($streamingUrl, 'r', false, $context))
		{
			$buffer = stream_get_contents($stream, $headervalue['int'], $offset);
			fclose($stream);
			if (strpos($buffer, $needle) !== false)
			{
				$title = explode($needle, $buffer)[1];
				App::setSessionVar('streamingurl',$streamingUrl.'<^edelemsep^>'.( $headervalue['int']*($limit+1) ).'<^edelemsep^>'.$headervalue['name']);  
				return substr($title, 1, strpos($title, ';') - 2);
			}
			else
				return self::getMp3StreamTitle($name,$streamingUrl, $headervalue['int'], $offset + $headervalue['int'], false,($limit+1) );
		}
		else{
			return false;
		}
	}

}


