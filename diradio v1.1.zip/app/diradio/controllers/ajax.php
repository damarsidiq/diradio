<?php
Class Ajax extends Controller{
    function __construct(){
        parent::__construct();
    }
    
    public function test()
    {
        echo Pxpedia::$browser;
        echo Pxpedia::$visitorip;
        
        return 'ajax';
    }
}
?>