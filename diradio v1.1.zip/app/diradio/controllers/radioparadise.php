<?php

Class Radioparadise extends Controller{
    var $urlidx;
    var $urlx;
    var $radioname;
    var $recordprog = true;
    var $recordmode = 'fopen';
    var $recordtry = 0;
    var $recordingfile = false;
    function __construct() {
        parent::__construct();
        $this->radioname = '';
        $this->setPagevar('ajax',true);
    }
    public function pageInit($data=null,$view='radioparadise'){
        
    }
    public function recordingprogress($ch,$max,$sofar,$up1,$up2){
        if(!file_exists(App::getConfig('uploads').'recordsession.dreco')){
            @curl_close($ch);
            exit();
        }
    }
    public function startrecordingwindow(){
        $this->setPagevar('windowopen',1);
        $this->setPagevar('ajax',false);
        $this->setPagevar('stoprecord','0');
        return 'recording';
    }
    public function startrecording($data){
        date_default_timezone_set("Asia/Jakarta");
        $recording = date('Y-m-d H:i:s',time()).'-'. App::getSessionVar('currentradio').'.dreco.mp3';
        App::setSessionVar('dreco',$recording);
        
        if(isset($data['radio'])){
            App::setSessionVar('recording',true);
            $recsess = @fopen(App::getConfig('uploads').'recordsession.dreco','ab');
            if($recsess){
                fwrite($recsess,App::getSessionVar('dreco').'<%edsep%>'.App::getSessionVar('currenturl').'<edsep>');
                
                $response['result'] = true;
                $this->setPagevar('response',$response);
                
                return 'ajax';
            }
            else{
                $response['result'] = false;
                $response['debug'] = 2;
                $response['verbosedebug'] = App::getSessionVar('currenturl').var_export($info).' # ';
                $this->setPagevar('response',$response);
                
                return 'ajax';
            }   
        }
        
        $recs = file_get_contents(App::getConfig('uploads').'recordsession.dreco');
        $recsx = explode('<edsep>',$recs);
        foreach($recsx as $rk=>$va){
            if($va ==''){
                continue;
            }
            $vaurl = explode('<%edsep%>',$va);
            $vaurl = $vaurl[1];
            $va = $va[0];
            
            App::setSessionVar('currenturl',$vaurl);
            
            if(!file_exists(App::getConfig('uploads').'records/'.$va)){
                $filepath = App::getConfig('uploads').'records/'.$recording;
                $this->recordingfile = @fopen($filepath,'wb');
                
                if(!$this->recordingfile){
                    $response['result'] = false;
                    $response['debug'] = 1;
                    $this->setPagevar('response',$response);
                    return 'ajax';
                }       
                
                break;
            }
        }
        $scv = $this->startrecording_();
        if($scv !== true){
            return 'ajax';
        }
        
        $response['result'] = true;
        $response['debug'] = 4;
        $response['verbosedebug'] = ' # ';
        $this->setPagevar('response',$response);
        
        return 'ajax';
    }
    public function startrecording_(){
        switch($this->recordmode){
            case 'curl':
                $ch = @curl_init();
                @curl_setopt($ch, CURLOPT_URL, App::getSessionVar('currenturl'));
                @curl_setopt($ch, CURLOPT_RETURNTRANSFER, false);
                @curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    'Icy-MetaData: 1'
                ));
                if($this->recordprog){
                    @curl_setopt($ch, CURLOPT_NOPROGRESS, false);
                    @curl_setopt($ch, CURLOPT_PROGRESSFUNCTION, array($this,'recordingprogress'));            
                }
                @curl_setopt($ch, CURLOPT_FILE, $this->recordingfile);
                @curl_setopt($ch, CURLOPT_BUFFERSIZE, (65536));
                @curl_setopt($ch, CURLOPT_HEADER, false); 
                
                $cexec = @curl_exec($ch);
                if ($cexec === false) {
                    $info = @curl_getinfo($ch);
                    @curl_close($ch);
                    
                    $response['result'] = false;
                    $response['debug'] = 2;
                    $response['verbosedebug'] = App::getSessionVar('currenturl').print_r($info,true).' # ';
                    $this->setPagevar('response',$response);
                    
                    return 'ajax';
                }
                else{
                    @curl_close($ch); 
                    if(filesize($filepath) == 0){
                        $this->recordtry+=1;
                        if($this->recordtry > 1){
                            return;
                        }
                        $this->recordmode = 'fopen';
                        $this->startrecording_();
                    }
                    else{
                        return true;
                    }
                }           
            break;
            case 'fopen':
                $ch = @fopen(App::getSessionVar('currenturl'),'rb');
                if($ch){
                    while(!feof($ch)){
                        if(!file_exists(App::getConfig('uploads').'recordsession.dreco')){
                            break;
                        }
                        else
                            @fwrite($this->recordingfile,fread($ch, 8192));
                    }
                    fclose($ch);
                    
                    if(filesize($filepath) < 1024){
                        $this->recordtry+=1;
                        if($this->recordtry > 1){
                            return;
                        }
                        $this->recordmode = 'curl';
                        $this->startrecording_();
                    }
                    else{
                        fclose($this->recordingfile);
                        return true;
                    }
                }
                else{
                    $this->recordtry+=1;
                    if($this->recordtry > 1){
                        $response['result'] = false;
                        $response['debug'] = 4;
                        $response['verbosedebug'] = print_r($ch,true).' # ';
                        $this->setPagevar('response',$response);
                        
                         return 'ajax';
                    }
                    else{
                        $this->recordmode = 'curl';
                        $this->startrecording_();                            
                    }
                }
            break;
        }
    }
    public function stoprecording($data){
        $this->setPagevar('ajax',false);
        $this->setPagevar('stoprecord','0');
        
        if(App::isMobile()){
            $this->setPagevar('mobile','true');
            $this->addheadfootsrc(array('diradiomobile'=>App::getConfig('appviews').'/styles/mobile.css'),false);
        }
        
        if(isset($data['open'])){
            $this->setPagevar('open','1');
        }
        
        if(file_exists(App::getConfig('uploads').'recordsession.dreco')){
            $url = file_get_contents(App::getConfig('uploads').'recordsession.dreco');
            $urlx = array();
            foreach(explode('<edsep>',$url) as $k=>$v){
                if($v != ''){
                    $urlx[] = App::getConfig('uploads').'records/'.explode('<%edsep%>',$v)[0];
                }
            }
            
            $delrec = unlink(App::getConfig('uploads').'recordsession.dreco');
            if($delrec === true){
                $this->setPagevar('recordingurl',$urlx);
                return 'recording';
            }
            else{
                echo print_r($delrec,true);
                return 'plain';
            }
        }
        echo '<div style="display:table;height:100%;width:100%;"><div style="display:table-cell;height:100%;width:100%;vertical-align:middle;text-align:center;font-size:18px">none found</div></div>';
        return 'plain';
    }
    
    public function remotesignalreceived(){
        $response = true;
        $abtp   = @fopen(App::getConfig('uploads').'remote.abtp','r');
        $remote = fread($abtp,filesize(App::getConfig('uploads').'remote.abtp'));
        
        if($remote != 'false'){
            $response = false;
        }
        $this->setPagevar('response',$response);
        
        return 'ajax';
    }
    public function selectremoteradio($data){
        $this->streamradio($data);
        
        $abtp = @fopen(App::getConfig('uploads').'remote.abtp','w');
        $update = fputs($abtp,$data['radio'].'<^edsep^>'.$data['vol']);
        
        $this->setPagevar('response',$update);
        
        return 'ajax';
    }
    public function checkremote($data){
        $response = array();
        $response['command'] = false;
        $response['radioid'] = false;
        
        $abtp = @fopen(App::getConfig('uploads').'remote.abtp','r');
        $remote = fread($abtp,filesize(App::getConfig('uploads').'remote.abtp'));
        
        if($remote != 'false'){
            $response['command'] = true;
            $remoteresponse = explode('<^edsep^>',$remote);
            $response['radioid'] = $remoteresponse[0];
            $response['radiovol'] = $remoteresponse[1];
            
            $this->streamradio(array('radio'=>$response['radioid']));
            
            $rabtp = @fopen(App::getConfig('uploads').'remote.abtp','w');
            $update = fputs($rabtp,'false');
        }
        else{
            $response['command'] = $remote;
            $response['radioid'] = 'sofasgoo';
        }
        $this->setPagevar('response',$response);
        
        return 'ajax';
    }
    
    public function streamradio($data){
        $list       = file_get_contents(App::getConfig('uploads').$data['radio'].'.sbtp');
		$this->urlx = explode('<*edelemsep*>',$list);
		
		$this->radioname = $data['radio'];
		App::setSessionVar('currentradio',$this->radioname);
		
		$abtp = @fopen(App::getConfig('uploads').'diradio.abtp','w');
        $update = fputs($abtp,$this->radioname);
		
		
		$this->setPagevar('url',$this->geturlidx());
    }
    public function geturlidx(){
        $this->urlidx = App::getSessionVar($this->radioname.'urlidx');
        if($this->urlidx === false){
            $this->urlidx = 0;
        }
        else{
            $this->urlidx++;
        }
        if(!isset($this->urlx[$this->urlidx]) || $this->urlx[$this->urlidx] == ''){
            $this->urlidx = 0;
        }
        
        if(strpos($this->urlx[$this->urlidx],'<*edsep*>') !== false){
            $currenturlx = explode('<*edsep*>',$this->urlx[$this->urlidx]);
            $currenturl = $currenturlx[0];
            
            $icyurl = $currenturlx[1];
        }
        else{
            $currenturl = $this->urlx[$this->urlidx];
            $icyurl     = $currenturl;
        }
        
        App::setSessionVar($this->radioname.'urlidx',$this->urlidx);
        App::setSessionVar('currenturl',trim($currenturl));
        App::setSessionVar('icyurl',trim($icyurl));
        
        return App::getSessionVar('currenturl');
    }
}