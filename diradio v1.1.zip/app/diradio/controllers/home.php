<?php

Class Home extends Controller{
    var $path;
    function __construct() {
        parent::__construct();
        $this->path = App::getConfig('uploads');
        $this->setPagevar('mobile','false');
    }
    public function pageInit($data=null,$view='home'){
        if(file_exists(App::getConfig('uploads').'recordsession.dreco')){
            $this->setPagevar('stoprecord','1');
        }
        else{
            $this->setPagevar('stoprecord','0');
        }
        $plss = $this->getFiles();
        $plss = $this->controller('sortfile')->pageInit($plss);
        $this->setPagevar('pls',$plss);
        
        
        if(App::isMobile()){
            $this->setPagevar('mobile','true');
            $this->addheadfootsrc(array('diradiomobile'=>App::getConfig('appviews').'/styles/mobile.css'),false);
        }
		return $view;
    }
    
    public function getFiles($path=false,$plss=false){
        $plss = $path === false ? array() : $plss;
        $filehandle = opendir($this->path);
		while(false !== ($file = readdir($filehandle))){
			if(strpos($file,'.sbtp') !== false && $file != '.' && $file != '..' && $file != 'sessionsvarvals.abtp' && $file != 'currentlyplaying.abtp' &&  $file != 'remote.abtp' &&  $file != 'diradio.abtp' && strpos($file,'.dreco')===false){
			    if(!is_dir($path.'/'.$file)){
			        $namex = explode('.',$file);
			        if($namex[0]!= '')
			            $plss[] = $namex[0];
			    }
			    else{
			        $plss = array_merge($plss,$this->getFiles($path.'/'.$file,$files));
			    }
			}
		}
		return $plss;
    }
    
    public function songtitle(){
        $this->setPagevar('response',App::getMp3StreamTitle(App::getSessionVar('currentradio'),App::getSessionVar('currenturl'), 19200,0,true,0) );
        
        $abtp   = @fopen(App::getConfig('uploads').'currentlyplaying.abtp','w');
        if($this->getPagevar('response') === false){
            $update = fputs($abtp,App::getSessionVar('icyurl'));
        }
        else{
            $response['title'] = strtolower($this->getPagevar('response'));
            $response['name'] = explode('<^edelemsep^>',App::getSessionVar('streamingurl'))[2];
            $this->setPagevar('response',$response);
            $update = fputs($abtp,$response['title']);
            
            $abtp   = @fopen(App::getConfig('uploads').'sessionsvarvals.abtp','w');
            $update = fputs($abtp,App::getSessionVar('streamingurl').'<%edelemsep%>'.App::getSessionVar('currentradio').'<%edelemsep%>'.App::getSessionVar('currenturl'));
        }
        return 'ajax';
    }
    public function currentlyplaying(){
        $plss = $this->getFiles();
        $plss = $this->controller('sortfile')->pageInit($plss);
        $this->setPagevar('pls',$plss);
    
        $playing = '';    
        if(filesize(App::getConfig('uploads').'currentlyplaying.abtp') > 0){
            $abtp = @fopen(App::getConfig('uploads').'currentlyplaying.abtp','r');
            $playing = fread($abtp,filesize(App::getConfig('uploads').'currentlyplaying.abtp'));
        }
        
        $abtp = @fopen(App::getConfig('uploads').'diradio.abtp','r');
        $diradio = fread($abtp,filesize(App::getConfig('uploads').'diradio.abtp'));
        
        $abtp = @fopen(App::getConfig('uploads').'sessionsvarvals.abtp','r');
        $sessionsvarvals = fread($abtp,filesize(App::getConfig('uploads').'sessionsvarvals.abtp'));
        $sessionsvarvalsx = explode('<%edelemsep%>',$sessionsvarvals);
        App::setSessionVar('currenturl',$sessionsvarvalsx[2]);
        App::setSessionVar('streamingurl',$sessionsvarvalsx[0]);
        App::setSessionVar('currentradio',$sessionsvarvalsx[1]);
        
        $this->setPagevar('cplaying',$playing);
        $this->setPagevar('cplayingdiradio',$diradio);
        
        if(App::isMobile()){
            $this->setPagevar('mobile','true');
        }
        return 'cplaying';
    }
    public function updatecplaying($data){
        $playing = '';
        if(filesize(App::getConfig('uploads').'currentlyplaying.abtp') > 0){
            $abtp = @fopen(App::getConfig('uploads').'currentlyplaying.abtp','r');
            $playing = fread($abtp,filesize(App::getConfig('uploads').'currentlyplaying.abtp'));            
        }

        $this->setPagevar('cplaying',$playing);
        
        $this->setPagevar('ajax',true);
        return 'cplayingcontent';
    }
    public function testes($data){
        return 'home';
    }
    public function tes2($data){
        $ti = App::getMp3StreamTitle('dolargeneral',$data['url'], 19200,0,true,0);
        echo $ti.'$$$';
        echo (App::getSessionVar('streamingurl'));
        
        return 'plain';
    }
    public function tes($data){		
        $needle = 'StreamTitle=';
		$ua = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36';
		$opts = [
			'http' => [
				'method' => 'GET',
				'header' => 'Icy-MetaData: 1',
				'user_agent' => $ua
			]
		];
		
		if (($headers = get_headers($data['url']))){
		    echo print_r($headers,true);
		}
		
		
        return 'ajax';
    }
}




