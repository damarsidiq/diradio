var audio = false;
var selectedradio = false;
var checker = false;
var timelimit = 0;
var selectedradioicy = true;
var aflag = false;
var switchradio = false;
var remotesignalpending = false;
var selectedradiovol = 1;
var viewmode = 1;
var hoveredradio = false;
var cradiourl = false;

function toggleviewmode(){
    if($('#playlist').attr('class').indexOf('active') !== -1){
        $('#playlist').removeClass('active');
        $('#thecontent').addClass('active');
        viewmode = 0;
    }
    else{
        $('#playlist').addClass('active');
        $('#thecontent').removeClass('active');
        viewmode = 1;
    }
}

function keyboardbind(){
    $('body').on('keydown',function(event){
        event.stopPropagation();
        
        switch(event.which){
            case 109:
                event.preventDefault();
                if(audio !== false && !audio.paused){
                    selectedradiovol    -= 0.1; 
                    audio.volume        = selectedradiovol;
                }
            break;
            case 107:
                event.preventDefault();
                if(audio !== false && !audio.paused){
                    selectedradiovol    += 0.1; 
                    audio.volume        = selectedradiovol;
                }
            break;
            case 40:
                event.preventDefault();
                if(viewmode){
                    if(hoveredradio === false){
                        if($('#playlist').children('.active').length){
                            $('#playlist').children('.active').addClass('hovered');
                        }
                        else
                            $('#playlist').children().eq(0).addClass('hovered');
                    }
                    else{
                        $(hoveredradio).removeClass('hovered');
                        if(typeof $(hoveredradio).next().attr('id') === 'undefined'){
                            $('#playlist').children().eq(0).addClass('hovered');    
                        }
                        else{
                            $(hoveredradio).next().addClass('hovered');
                        }
                    }
                    hoveredradio = $('#playlist').children('.hovered');
                    $(hoveredradio)[0].scrollIntoView();
                }
            break;
            case 38:
                event.preventDefault();
                if(viewmode){
                    if(hoveredradio === false){
                        if($('#playlist').children('.active').length){
                            $('#playlist').children('.active').addClass('hovered');
                        }
                        else{
                            $('#playlist').children().eq($('#playlist').children().length-1).addClass('hovered');
                            $('#playlist').children().eq($('#playlist').children().length-1)[0].scrollIntoView(); 
                        }
                        hoveredradio = $('#playlist').children('.hovered');  
                    }
                    else{
                        $(hoveredradio).removeClass('hovered');
                        if(typeof $(hoveredradio).prev().attr('id') === 'undefined'){
                            $('#playlist').children().eq($('#playlist').children().length-1).addClass('hovered');    
                        }
                        else{
                            $(hoveredradio).prev().addClass('hovered');
                        }
                        hoveredradio = $('#playlist').children('.hovered');
                    }
                    $(hoveredradio)[0].scrollIntoView();
                }
            break;
            case 32:
                event.preventDefault();
                if(!viewmode){
                    if(typeof ($('#stopandplay').attr('class')) !== 'undefined'){
                        if( $('#stopandplay').attr('class').indexOf('stopped') !== -1){
                            $('#stopandplay').removeClass('stopped');
                            stopandplayhandler(true);
                        }
                        else{
                            $('#stopandplay').addClass('stopped');
                            stopandplayhandler(false);
                        }
                    }
                    else{
                        $('#stopandplay').addClass('stopped');
                        stopandplayhandler(false);
                    }
                }
            break;
            case 13:
                event.preventDefault();
                if(viewmode && hoveredradio !== false){
                    if(remote){
                        $('#playlist').children('.active').removeClass('active');
                        $(hoveredradio).addClass('active');
                        $('#songtitle').addClass('loading');
                        
                        $('#playlist').removeClass('active');
                        $('#thecontent').addClass('active');
                        
                        selectedradio = $(hoveredradio).attr('id');
                        $.ajax({
                            url:'./',
                            type:'POST',
                            data:{app:appname,p:'radioparadise',a:'selectremoteradio',d:{radio:selectedradio,vol:selectedradiovol}}
                        }).done(function(msg){
                            try{
                                msg = JSON.parse(msg);    
                            }
                            catch(e){
                                checksignalreceive();   
                            }
                        });
                        
                        return;
                    }
                    if(audio !== false){
                        switchradio = true;
                        audio.pause();
                    }
                    
                    $('#playlist').children('.active').removeClass('active');
                    $(hoveredradio).addClass('active');
                    
                    selectedradio = $(hoveredradio).attr('id');
                    updateradio(true);
                }
                else{
                     if(audio !== false && !audio.paused){
                         $('#songtitle').addClass('loading');
                         songtitle(false);
                     }
                }
            break;
            case 9:
                event.preventDefault();
                toggleviewmode();
            break;
            default:
            break;
        }
    });
}




function songtitle(flagged){
    if(!flagged && aflag){
        return;
    }
    if( (selectedradioicy && audio !== false && !audio.paused ) || remote){
        var pagea = 'songtitle';
        if(remote && !flagged){
            pagea = 'updatecplaying';
        }
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'home',a:pagea}
        }).done(function(msg){
            
            if(msg != 'false'){
                try{
                    msg = JSON.parse(msg);
                    
                    selectedradioicy = true;
                    
                    if(remote && !flagged){
                        $('#songtitle').find('.table').replaceWith(msg.pagecontent);
                    }
                    else{
                        $('#songtitle').find('.tablecell').html('<div>'+msg.name+':</div><div>'+msg.title+'</div>');    
                    }
                    $('#songtitle').removeClass('empty');
                    $('#songtitle').removeClass('loading');
                }
                catch(e){
                    
                }

                
                if(flagged && aflag){
                    aflag = false;
                }
                
                
                setTimeout(function(){
                    songtitle(false);
                },210000);                    
            }
            else{
                selectedradioicy = false;
                $('#songtitle').find('.tablecell').html('<div>'+selectedradio+':</div><div>title not available</div>');
                $('#songtitle').removeClass('empty');
                $('#songtitle').removeClass('loading');
            }
        });   
    }
}


function playstreamed(){
    if(audio.readyState == 3){
        audio.play();
        audio.volume = selectedradiovol;
        $('#audioisloading').addClass('hide');
        $('#audioplayer').removeClass('hide');
        songtitle(false);
        
        $(audio).on('pause',function(event){
            updateradio(false);
        });
        return;
    }
    setTimeout(function(){
        if(audio.paused){
            if(audio.readyState == 3){
                audio.play();
                audio.volume = selectedradiovol;
                $('#audioisloading').addClass('hide');
                $('#audioplayer').removeClass('hide');
                songtitle(false);
                
                $(audio).on('pause',function(event){
                    updateradio(false);
                });
            }
            else{
                if(timelimit > 3){
                    checkerfn();
                }
                else{
                    timelimit++;
                    playstreamed();
                }
            }
        }
        else{
            audio.volume = selectedradiovol;
            $('#audioisloading').addClass('hide');
            $('#audioplayer').removeClass('hide');
            $(audio).on('pause',function(event){
                updateradio(false);
            });
            songtitle(false);
        }
    },5000);
}
function updateradio(switched){
    if(switchradio && !switched)
        return;
        
    viewmode = 0;
        
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'radioparadise',a:'streamradio',d:{radio:selectedradio}}
    }).done(function(msg){
        
        try{
            msg = JSON.parse(msg);    
            
            switchradio = false;
            cradiourl = msg.pagecontent;
        
            $('#playlist').removeClass('active');
            $('#thecontent').html('<div id="songtitle" class="loading"><div class="table"><div class="tablecell"></div></div></div><div id="stopandplayradio"><div id="stopandplay"><div class="table"><div class="tablecell"></div></div></div></div><div id="audioisloading"><div class="table"><div class="tablecell">Loading...</div></div></div><audio id="audioplayer" autoplay="true" controls="controls" src="'+msg.pagecontent+'?timed='+new Date().getTime()+'" class="hide"></audio>').addClass('active');
            
            $('#songtitle').children().children().html(selectedradio);
            
            audio = $('#audioplayer')[0];
            timelimit = 0;
            selectedradioicy = true;
            playstreamed();
        }
        catch(e){
            
        }
    });
}
function checkerfn(){
    setTimeout(function(){
        if(audio.paused){
            updateradio();
        }
        else{
            checkerfn();
        }
    },5000);
}

function remotesignal(){
    setInterval(function(){
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'radioparadise',a:'checkremote'}
        }).done(function(msg){
            try{
                remotesignalpending = false;
                msg = JSON.parse(msg);
                
                if(msg.command === true){
                    $('#playlist').children('.active').removeClass('active');
                    $('#'+msg.radioid).addClass('active');
                    

                    if(msg.radioid != 'false'){
                        selectedradio       = msg.radioid;
                        selectedradiovol    = msg.radiovol;
                        updateradio(true);
                    }
                    else{
                        selectedradiovol    = msg.radiovol;
                        audio.volume = selectedradiovol;
                    }
                }
            }
            catch(e){

            }
        });
    },10000);    
}

function checksignalreceive(){
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'radioparadise',a:'remotesignalreceived'}
    }).done(function(msg){
        try{
            msg = JSON.parse(msg);
            if(msg === false){
                setTimeout(function(){
                    checksignalreceive();        
                },5000);
            }
            else{
                songtitle(true);
            }
        }
        catch(e){
            
        }
    });
}

function stopandplayhandler(play){
    if(play){
        try{
            switchradio = false;
            $('#thecontent').html('<div id="songtitle" class="loading"><div class="table"><div class="tablecell"></div></div></div><div id="stopandplayradio"><div id="stopandplay"><div class="table"><div class="tablecell"></div></div></div></div><div id="audioisloading"><div class="table"><div class="tablecell">Loading...</div></div></div><audio id="audioplayer" autoplay="true" controls="controls" src="'+cradiourl+'?timed='+new Date().getTime()+'" class="hide"></audio>').addClass('active');
            
            $('#songtitle').children().children().html(selectedradio);
            
            audio = $('#audioplayer')[0];
            timelimit = 0;
            selectedradioicy = true;
            playstreamed();
        }
        catch(e){
            
        }   
    }
    else{
        audio.pause();
        $(audio).remove();
    }
}

$(document).ready(
    function(){
        if(!mobile){
            keyboardbind();
        }
        
        if(!remote){
            remotesignal();
        }
        else{
            $('#playlist').removeClass('active');
            $('#thecontent').addClass('active');
        }
        
        $('body').delegate('#songtitle','click',function(event){
            event.stopPropagation();
                
            $(this).addClass('loading');
            aflag = true;
            
            songtitle(true);
        });
        
        $('body').delegate('#stopandplay','click',function(event){
            event.stopPropagation();
            
            if(typeof ($(this).attr('class')) !== 'undefined'){
                if( $(this).attr('class').indexOf('stopped') !== -1){
                    $(this).removeClass('stopped');
                    stopandplayhandler(true);
                }
                else{
                    $(this).addClass('stopped');
                    stopandplayhandler(false);
                }
            }
            else{
                $(this).addClass('stopped');
                stopandplayhandler(false);
            }
        });
        
        $('body').delegate('#playlist li','click',function(){
            if(remote){
                $('#playlist').children('.active').removeClass('active');
                $(this).addClass('active');
                $('#songtitle').addClass('loading');
                
                $('#playlist').removeClass('active');
                $('#thecontent').addClass('active');
                
                selectedradio = $(this).attr('id');
                $.ajax({
                    url:'./',
                    type:'POST',
                    data:{app:appname,p:'radioparadise',a:'selectremoteradio',d:{radio:selectedradio,vol:selectedradiovol}}
                }).done(function(msg){
                    try{
                        msg = JSON.parse(msg);    
                    }
                    catch(e){
                        checksignalreceive();   
                    }
                });
                
                return;
            }
            if(audio !== false){
                switchradio = true;
                audio.pause();
            }
            
            $('#playlist').children('.active').removeClass('active');
            $(this).addClass('active');
            
            selectedradio = $(this).attr('id');
            updateradio(true);
        });
        
        $('body').delegate('#volumec span','click',function(event){
            event.stopPropagation();
            $(this).addClass('justclicked');
            var volumecclicked = this;
            setTimeout(function(){
                $(volumecclicked).removeClass('justclicked');
            },300);
            
            switch($(this).html()){
                case '-':
                    selectedradiovol = Math.max((selectedradiovol- 0.1),0);
                break;
                case '+':
                    selectedradiovol = Math.min((selectedradiovol + 0.1),1);
                break;
            }
            $('#spica').html(Math.round((selectedradiovol*100)) + '%');
            
                $.ajax({
                    url:'./',
                    type:'POST',
                    data:{app:appname,p:'radioparadise',a:'selectremoteradio',d:{radio:false,vol:selectedradiovol}}
                }).done(function(msg){
                    try{
                        msg = JSON.parse(msg);    
                    }
                    catch(e){
                        
                    }
                });
        });
        
        $('header').on('click',function(event){
            event.stopPropagation();
            toggleviewmode();
        });
        
        $('#apptitle').on('click',function(event){
            event.stopPropagation();
            ipcRenderer.send('asynchronous-message', 'quitbro<edsep>');
        });
    }
);