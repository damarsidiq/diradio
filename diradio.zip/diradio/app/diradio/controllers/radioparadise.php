<?php

Class Radioparadise extends Controller{
    var $urlidx;
    var $urlx;
    var $radioname;
    function __construct() {
        parent::__construct();
        $this->radioname = '';
        $this->setPagevar('ajax',true);
    }
    public function pageInit($data=null,$view='radioparadise'){
        
    }
    
    public function remotesignalreceived(){
        $response = true;
        $abtp   = @fopen(App::getConfig('uploads').'remote.abtp','r');
        $remote = fread($abtp,filesize(App::getConfig('uploads').'remote.abtp'));
        
        if($remote != 'false'){
            $response = false;
        }
        $this->setPagevar('response',$response);
        
        return 'ajax';
    }
    public function selectremoteradio($data){
        $this->streamradio($data);
        
        $abtp = @fopen(App::getConfig('uploads').'remote.abtp','w');
        $update = fputs($abtp,$data['radio'].'<^edsep^>'.$data['vol']);
        
        $this->setPagevar('response',$update);
        
        return 'ajax';
    }
    public function checkremote($data){
        $response = array();
        $response['command'] = false;
        $response['radioid'] = false;
        
        $abtp = @fopen(App::getConfig('uploads').'remote.abtp','r');
        $remote = fread($abtp,filesize(App::getConfig('uploads').'remote.abtp'));
        
        if($remote != 'false'){
            $response['command'] = true;
            $remoteresponse = explode('<^edsep^>',$remote);
            $response['radioid'] = $remoteresponse[0];
            $response['radiovol'] = $remoteresponse[1];
            
            $this->streamradio(array('radio'=>$response['radioid']));
            
            $rabtp = @fopen(App::getConfig('uploads').'remote.abtp','w');
            $update = fputs($rabtp,'false');
        }
        else{
            $response['command'] = $remote;
            $response['radioid'] = 'sofasgoo';
        }
        $this->setPagevar('response',$response);
        
        return 'ajax';
    }
    
    public function streamradio($data){
        $list       = file_get_contents(App::getConfig('uploads').$data['radio'].'.sbtp');
		$this->urlx = explode('<*edelemsep*>',$list);
		
		$this->radioname = $data['radio'];
		App::setSessionVar('currentradio',$this->radioname);
		
		$abtp = @fopen(App::getConfig('uploads').'diradio.abtp','w');
        $update = fputs($abtp,$this->radioname);
		
		
		$this->setPagevar('url',$this->geturlidx());
    }
    public function geturlidx(){
        $this->urlidx = App::getSessionVar($this->radioname.'urlidx');
        if($this->urlidx === false){
            $this->urlidx = 0;
        }
        else{
            $this->urlidx++;
        }
        if(!isset($this->urlx[$this->urlidx]) || $this->urlx[$this->urlidx] == ''){
            $this->urlidx = 0;
        }
        
        if(strpos($this->urlx[$this->urlidx],'<*edsep*>') !== false){
            $currenturlx = explode('<*edsep*>',$this->urlx[$this->urlidx]);
            $currenturl = $currenturlx[0];
            
            $icyurl = $currenturlx[1];
        }
        else{
            $currenturl = $this->urlx[$this->urlidx];
            $icyurl     = $currenturl;
        }
        
        App::setSessionVar($this->radioname.'urlidx',$this->urlidx);
        App::setSessionVar('currenturl',trim($currenturl));
        App::setSessionVar('icyurl',trim($icyurl));
        
        return App::getSessionVar('currenturl');
    }
}