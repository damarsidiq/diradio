<?php

Class Sortfile extends Controller{
    function __construct() {
        parent::__construct();
    }
    public function pageInit($data,$view='home'){
        $records = $data;
        uasort($records,function($a,$b){
            $sortf = strtolower($a)< strtolower($b) ? -1 : (strtolower($a) == strtolower($b) ? 0 : 1);
            if($sortf!=0){
                return $sortf;
            }
        });
        
        return $records;
    }
}
	

?>