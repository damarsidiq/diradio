<script type="text/javascript">
var remote = true;
</script>