<script type="text/javascript">
var remote = false;
</script>