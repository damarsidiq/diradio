<script type="text/javascript">
var mobile = <?php echo $pagevar['mobile']; ?>;
</script>
</body>
<?php $velp->printfootsrc(); ?>
</html>