<!DOCTYPE html><html>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="robots" content="all">
    <?php $velp->printheadsrc(); ?>
    <title></title>
</head>
<body>
    <header>
        <div class="table">
            <div class="tablecell">
                <span id="apptitle">DiradiO</span>
            </div>
        </div>
    </header>
    <?php if(isset($pagevar['pls'])){ ?>
        <ul id="playlist" class="list active">
            <?php
                $number = 0;
                foreach($pagevar['pls'] as $k=>$v){
                    if(isset($pagevar['cplayingdiradio']) && $v == $pagevar['cplayingdiradio']){
                    ?>
                        <li id="<?php echo $v; ?>" class="active"><?php echo ($number+1).'. '.$v; ?></li>
                    <?php
                    }
                    else{
                    ?>
                        <li id="<?php echo $v; ?>"><?php echo ($number+1).'. '.$v; ?></li>
                    <?php
                    }
                    $number+=1;
                }
            ?>
        </ul>
    <?php } ?>
        <div id="thecontent">
            <?php if(isset($pagevar['cplaying'])){ ?>
                <div id="songtitle">
                    <div class="table">
                        <div class="tablecell">
                            <?php
                            
                            echo $pagevar['cplaying'];
                            
                            ?>
                        </div>
                    </div>   
                    <div id="spica">100%</div>
                </div>
                
                <div id="volumec">
                    <span>-</span>
                    <span>+</span>
                </div>
            <?php } ?>
        </div>